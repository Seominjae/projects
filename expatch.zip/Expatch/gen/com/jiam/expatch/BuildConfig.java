/** Automatically generated file. DO NOT MODIFY */
package com.jiam.expatch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}